import pandas as pd
from summary.tourism import evaluate

meanmape = evaluate()
genericmean = pd.DataFrame(meanmape, index = ['SMAPE'])

print(genericmean)