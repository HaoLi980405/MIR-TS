from dataclasses import dataclass

import numpy as np
import pandas as pd

@dataclass()
class TourismMeta:
    seasonal_patterns = ['Yearly', 'Quarterly', 'Monthly']
    horizons = [4, 8, 24]
    frequency = [1, 4, 12]
    horizons_map = {
        'Yearly': 4,
        'Quarterly': 8,
        'Monthly': 24
    }
    frequency_map = {
        'Yearly': 1,
        'Quarterly': 4,
        'Monthly': 12
    }


@dataclass()
class TourismDataset:
    ids: np.ndarray
    groups: np.ndarray
    horizons: np.ndarray
    values: np.ndarray

    @staticmethod
    def load(training: bool = True) -> 'TourismDataset':
        """
        Load Tourism dataset from cache.

        :param training: Load training part if training is True, test part otherwise.
        """
        ids = []
        groups = []
        horizons = []
        values = []

        for group in TourismMeta.seasonal_patterns:

            train = pd.read_csv('Data/'+f'{group.lower()}_in.csv', header=0, delimiter=",")
            test = pd.read_csv('Data/'+f'{group.lower()}_oos.csv', header=0, delimiter=",")

            horizons.extend(list(test.iloc[0].astype(int)))
            groups.extend([group] * len(train.columns))

            if group == 'Yearly':
                train_meta = train[:2]
                meta_length = train_meta.iloc[0].astype(int)
                test = test[2:].reset_index(drop=True).T
                train = train[2:].reset_index(drop=True).T
            else:
                train_meta = train[:3]
                meta_length = train_meta.iloc[0].astype(int)
                test = test[3:].reset_index(drop=True).T
                train = train[3:].reset_index(drop=True).T

            ids.extend(list(train.index))

            if training:
                dataset = train
            else:
                dataset = test

            values.extend([ts[:ts_length] for ts, ts_length in zip(dataset.values, meta_length)])

        return TourismDataset(ids=np.array(ids),
                              groups=np.array(groups),
                              horizons=np.array(horizons),
                              values=np.array(values))

    def to_hp_search_training_subset(self):
        return TourismDataset(ids=self.ids,
                              groups=self.groups,
                              horizons=self.horizons,
                              values=np.array([v[:-self.horizons[i]] for i, v in enumerate(self.values)]))

TRAINING_DATASET_CACHE_FILE_PATH = 'Data/m4.npz'
INFO_FILE_PATH = 'Data/M4-info.csv'

@dataclass()
class M4Dataset:
    ids: np.ndarray
    groups: np.ndarray
    frequencies: np.ndarray
    horizons: np.ndarray
    values: np.ndarray

    @staticmethod
    def load(training: bool = True) -> 'M4Dataset':
        """
        Load cached dataset.

        :param training: Load training part if training is True, test part otherwise.
        """
        m4_info = pd.read_csv(INFO_FILE_PATH)
        return M4Dataset(ids=m4_info.M4id.values,
                         groups=m4_info.SP.values,
                         frequencies=m4_info.Frequency.values,
                         horizons=m4_info.Horizon.values,
                         values=np.load('m4.npz', allow_pickle=True))