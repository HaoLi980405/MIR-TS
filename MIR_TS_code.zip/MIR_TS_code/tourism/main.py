from typing import Dict
import numpy as np
import pandas as pd
import torch as t

from common.sampler import TimeseriesSampler
from common.torch.ops import to_tensor
from Data.tourism import TourismDataset, TourismMeta
from trainer import trainer
from model import MIR_TS
from summary.utils import group_values
from summary.tourism import evaluate


class TourismExperiment():
    def train(repeat: int,
              lookback: int,
              loss: str,
              history_size: Dict[str, float],
              iterations: Dict[str, int]):
        dataset = TourismDataset.load(training=True)
        
        forecasts = []
        for seasonal_pattern in TourismMeta.seasonal_patterns:
            history_size_in_horizons = history_size[seasonal_pattern]
            horizon = TourismMeta.horizons_map[seasonal_pattern]
            input_size = lookback * horizon

            # Training Set
            training_values = group_values(dataset.values, dataset.groups, seasonal_pattern)
            training_set = TimeseriesSampler(timeseries=training_values,
                                             insample_size=input_size,
                                             outsample_size=horizon,
                                             window_sampling_limit=int(history_size_in_horizons * horizon),
                                             batch_size = 1024)
            
            
            model = MIR_TS(input_size=input_size, output_size=horizon)

            model, alpha = trainer(model=model,
                            training_set=iter(training_set),
                            timeseries_frequency=TourismMeta.frequency_map[seasonal_pattern],
                            loss_name=loss,
                            iterations=iterations[seasonal_pattern])
            # Build forecasts
            x, x_mask = map(to_tensor, training_set.last_insample_window())
            model.eval()
            with t.no_grad():
                forecast = model(alpha, x, x_mask)
                forecasts.extend(forecast.cpu().detach().numpy())

        forecasts_df = pd.DataFrame(forecasts, columns=[f'V{i + 1}' for i in range(np.max(TourismMeta.horizons))])
        forecasts_df.index = dataset.ids
        forecasts_df.index.name = 'id'
        forecasts_df.to_csv('./forecast/forecast_repeat'+str(repeat)+'_lookback'+str(lookback)+'_loss'+loss+'.csv')

if __name__ == '__main__':
    history_size = {
    'Yearly': 5,
    'Quarterly': 10,
    'Monthly': 20
    }

    iterations = {
    'Yearly': 25,
    'Quarterly': 300,
    'Monthly': 300,
    }
    

    for i in range(5):
        for repeat in range(1,11):
            for loss in ['MAPE']:
                for lookback in range(2,6):
                    TourismExperiment.train(repeat = repeat,
                                    lookback = lookback, 
                                    loss = loss,
                                    history_size = history_size , 
                                    iterations = iterations)

        results = str(evaluate())
        with open("result.txt","a") as f:
            f.write(results+"\n")