import numpy as np
import torch as t

from models.MIRTS import GenericBasis, MIRTS, Block


def MIR_TS(input_size: int, output_size: int, 
        stacks: int = 20, layers: int = 2, 
        backcast_layer_size: int =256, forecast_layer_size: int=256):
   
    return MIRTS(t.nn.ModuleList([Block(input_size=input_size,
                                        theta_size=input_size,
                                        basis_function=GenericBasis(),
                                        layers=layers,
                                        layer_size=forecast_layer_size)
                                   for _ in range(stacks)]),
                 t.nn.ModuleList([Block(input_size=input_size,
                                        theta_size=output_size,
                                        basis_function=GenericBasis(),
                                        layers=layers,
                                        layer_size=backcast_layer_size)
                                   for _ in range(stacks)]))

    