import sys
sys.path.append("..")

from collections import OrderedDict
import numpy as np
from Data.tourism import TourismDataset, TourismMeta
from summary.utils import median_ensemble, group_values
from common.metrics import mape

def evaluate():
    
    forecast = median_ensemble()
    test_set = TourismDataset.load(training=False)

    results = OrderedDict()
    cumulative_metrics = 0
    cumulative_points = 0
    offset = 0
    for sp in TourismMeta.seasonal_patterns:
        target = group_values(test_set.values, test_set.groups, sp)
        sp_forecast = group_values(forecast, test_set.groups, sp)
        score = mape(sp_forecast, target)
        cumulative_metrics += np.sum(score)
        cumulative_points += np.prod(target.shape)
        results[sp] = round(float(np.mean(score)), 2)
        offset += len(target)

    results['Average'] = round(cumulative_metrics / cumulative_points, 2)
    return results



