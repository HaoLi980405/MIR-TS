
from typing import Tuple

import numpy as np
import torch as t
import torch.nn.functional as F
from common.torch.losses import smape_2_loss
from copy import deepcopy

class Block(t.nn.Module):
   
    def __init__(self,
                 input_size: int,
                 theta_size: int,
                 basis_function: t.nn.Module,
                 layers: int,
                 layer_size: int,
                 BN: bool=False):
       
        super().__init__()
        self.layers = t.nn.ModuleList([t.nn.Linear(in_features=input_size, out_features=layer_size)] +
                                      [t.nn.Linear(in_features=layer_size, out_features=layer_size)
                                       for _ in range(layers-1)])
        self.BacthNormX = t.nn.BatchNorm1d(input_size)
        self.BacthNorm = t.nn.BatchNorm1d(layer_size)
        self.basis_parameters = t.nn.Linear(in_features=layer_size, out_features=theta_size)
        self.basis_function = basis_function
        self.BN =BN

    def forward(self, x: t.Tensor) -> Tuple[t.Tensor, t.Tensor]:
        block_input = x
        for layer in self.layers:
            block_input = layer(block_input)
            block_input = t.relu(block_input)
        basis_parameters = self.basis_parameters(block_input)
        
        return self.basis_function(basis_parameters)
        
class MIRTS(t.nn.Module):

    def __init__(self, backcast_blocks: t.nn.ModuleList, forecast_blocks: t.nn.ModuleList):
        super().__init__()
        self.backcast_blocks = backcast_blocks
        self.forecast_blocks = forecast_blocks

    def forward(self, alpha, x: t.Tensor, input_mask: t.Tensor) -> t.Tensor:
        
        residuals = deepcopy(x)
        forecast = x[:, -1:]*alpha
        for i in range(len(self.backcast_blocks)):
            backcast = self.backcast_blocks[i](residuals)
            residuals = (residuals - backcast) * input_mask
            block_forecast = self.forecast_blocks[i](residuals)
            forecast = forecast + block_forecast
            
        
        return forecast


class GenericBasis(t.nn.Module):
    """
    Generic basis function.
    """
    def __init__(self):
        super().__init__()

    def forward(self, theta: t.Tensor):
        return theta

class TrendBasis(t.nn.Module):

    def __init__(self, degree_of_polynomial: int, timeseries_size: int):
        super().__init__()
        self.polynomial_size = degree_of_polynomial + 1  # degree of polynomial with constant term
        self.time = t.nn.Parameter(
            t.tensor(np.concatenate([np.power(np.arange(timeseries_size, dtype=np.float) / timeseries_size, i)[None, :]
                                     for i in range(self.polynomial_size)]), dtype=t.float32),
            requires_grad=False)

    def forward(self, theta: t.Tensor):
        
        timeseries = t.einsum('bp,pt->bt', theta, self.time)
        return timeseries

class SeasonalityBasis(t.nn.Module):

    def __init__(self, harmonics: int, time_size: int):
        super().__init__()
        self.frequency = np.append(np.zeros(1, dtype=np.float32),
                                   np.arange(harmonics, harmonics / 2 * time_size,
                                             dtype=np.float32) / harmonics)[None, :]
        time_grid = -2 * np.pi * (
                np.arange(time_size, dtype=np.float32)[:, None] / time_size) * self.frequency
        
        self.time_cos_template = t.nn.Parameter(t.tensor(np.transpose(np.cos(time_grid)), dtype=t.float32),
                                                    requires_grad=False)
        self.time_sin_template = t.nn.Parameter(t.tensor(np.transpose(np.sin(time_grid)), dtype=t.float32),
                                                    requires_grad=False)

    def forward(self, theta: t.Tensor):
        params_per_harmonic = theta.shape[1] // 4
        time_harmonics_cos = t.einsum('bp,pt->bt', theta[:, 2 * params_per_harmonic:3 * params_per_harmonic],
                                          self.time_cos_template)
        time_harmonics_sin = t.einsum('bp,pt->bt', theta[:, 3 * params_per_harmonic:], self.time_sin_template)
        timeseries = time_harmonics_sin + time_harmonics_cos

        return timeseries