import numpy as np
import torch as t

from models.MIRTS import Block, MIRTS, GenericBasis

def MI_RTS(input_size: int, output_size: int,
           stacks: int=30, layers: int=2, 
           backcast_layer_size: int=512, forecast_layer_size: int=512):
    
    return MIRTS(t.nn.ModuleList([Block(input_size=input_size,
                                          theta_size=input_size,
                                          basis_function=GenericBasis(),
                                          layers=layers,
                                          layer_size=backcast_layer_size)
                                   for _ in range(stacks)]),
               t.nn.ModuleList([Block(input_size=input_size,
                                          theta_size=output_size,
                                          basis_function=GenericBasis(),
                                          layers=layers,
                                          layer_size=forecast_layer_size)
                                   for _ in range(stacks)])
               )

    