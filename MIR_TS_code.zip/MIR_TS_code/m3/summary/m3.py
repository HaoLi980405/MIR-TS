import sys
sys.path.append("..")

from collections import OrderedDict
import numpy as np
from Data.M3Data import M3Dataset, M3Meta
from summary.utils import median_ensemble, median_ensemble_x, group_values
from common.metrics import smape_1
from common.sampler import TimeseriesSampler
from common.torch.ops import divide_no_nan

def mse(forecast, target):
    
    return np.array(np.mean((forecast - target)**2, axis=1),dtype=float)

def rse(target):
    return np.array(np.mean((target-np.mean(target, axis=1,keepdims=True))**2, axis=1),dtype=float)

def last_insample_window(timeseries, insample_size):
        
    insample = np.zeros((len(timeseries), insample_size))
    insample_mask = np.zeros((len(timeseries), insample_size))
    for i, ts in enumerate(timeseries):
        ts_last_window = ts[-insample_size:]
        insample[i, -len(ts):] = ts_last_window
        insample_mask[i, -len(ts):] = 1.0
    return insample, insample_mask

def evaluate():
    
    forecast = median_ensemble()
    test_set = M3Dataset.load(training=False)
    

    results = OrderedDict()
    cumulative_metrics = 0
    cumulative_points = 0
    offset = 0
    
    for sp in M3Meta.seasonal_patterns:
        target = group_values(test_set.values, test_set.groups, sp)
        sp_forecast = group_values(forecast, test_set.groups, sp)
        '''
        score_mse = mse(sp_forecast[:,0:1], target[:,0:1])
        score_rse = rse(target)
        score = np.mean(np.sqrt(score_mse/score_rse))
        '''
        score = smape_1(sp_forecast, target)
        cumulative_metrics += np.sum(score)
        cumulative_points += np.prod(target.shape)
        results[sp] = round(float(np.mean(score)), 2)
        offset += len(target)
            
    results['Average'] = round(cumulative_metrics / cumulative_points, 2)
    return results



