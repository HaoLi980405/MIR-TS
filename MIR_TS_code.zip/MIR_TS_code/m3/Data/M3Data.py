# -*- coding: utf-8 -*-
"""
Created on Sat Mar 13 17:41:21 2021

@author: Hao Li
"""
from dataclasses import dataclass
import numpy as np

TRAINING_SET_CACHE_FILE_PATH = 'Data/training.npy'
TEST_SET_CACHE_FILE_PATH = 'Data/test.npy'
IDS_CACHE_FILE_PATH = 'Data/ids.npy'
GROUPS_CACHE_FILE_PATH = 'Data/groups.npy'
HORIZONS_CACHE_FILE_PATH = 'Data/horizons.npy'

@dataclass()
class M3Meta:
    seasonal_patterns = ['M3Year', 'M3Quart', 'M3Month', 'M3Other']
    horizons = [6, 8, 18, 8]
    frequency = [1, 4, 12, 1]
    horizons_map = {
        'M3Year': 6,
        'M3Quart': 8,
        'M3Month': 18,
        'M3Other': 8
    }
    frequency_map = {
        'M3Year': 1,
        'M3Quart': 4,
        'M3Month': 12,
        'M3Other': 1
    }

@dataclass()

class M3Dataset:
    ids: np.ndarray
    groups: np.ndarray
    horizons: np.ndarray
    values: np.ndarray
    
    @staticmethod
    def load(training: bool = True) -> 'M3Dataset':
        values_file = TRAINING_SET_CACHE_FILE_PATH if training else TEST_SET_CACHE_FILE_PATH
        return M3Dataset(ids=np.load(IDS_CACHE_FILE_PATH, allow_pickle=True),
                         groups=np.load(GROUPS_CACHE_FILE_PATH, allow_pickle=True),
                         horizons=np.load(HORIZONS_CACHE_FILE_PATH, allow_pickle=True),
                         values=np.load(values_file, allow_pickle=True))

