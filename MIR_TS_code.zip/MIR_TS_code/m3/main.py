from typing import Dict

import numpy as np
import pandas as pd
import torch as t

from common.sampler import TimeseriesSampler
from common.torch.ops import to_tensor
from Data.M3Data import M3Dataset, M3Meta
from trainer import trainer
from model import MI_RTS
from summary.utils import group_values
import pandas as pd
from summary.m3 import evaluate

class M3Experiment():
    def train(repeat: int,
              lookback: int,
              loss: str,
              history_size: Dict[str, float],
              iterations: Dict[str, int]):
        dataset = M3Dataset.load(training=True)
        

        forecasts = []
        for seasonal_pattern in M3Meta.seasonal_patterns:
            history_size_in_horizons = history_size[seasonal_pattern]
            horizon = M3Meta.horizons_map[seasonal_pattern]
            input_size = lookback * horizon

            # Training Set
            training_values = group_values(dataset.values, dataset.groups, seasonal_pattern)
            training_set = TimeseriesSampler(timeseries=training_values,
                                             insample_size=input_size,
                                             outsample_size=horizon,
                                             window_sampling_limit=int(history_size_in_horizons * horizon),
                                             batch_size = 1024)
            
            
            model = MI_RTS(input_size=input_size, output_size=horizon)
           
            model = trainer(model=model,
                            training_set=iter(training_set),
                            timeseries_frequency=M3Meta.frequency_map[seasonal_pattern],
                            loss_name=loss,
                            iterations=iterations[seasonal_pattern])
            # Build forecasts
            x, x_mask = map(to_tensor, training_set.last_insample_window())
            model.eval()
            with t.no_grad():
                forecast = model(x, x_mask)
                forecasts.extend(forecast.cpu().detach().numpy())

        forecasts_df = pd.DataFrame(forecasts, columns=[f'V{i + 1}' for i in range(np.max(M3Meta.horizons))])
        forecasts_df.index = dataset.ids
        forecasts_df.index.name = 'id'
        forecasts_df.to_csv('./forecast/forecast_repeat'+str(repeat)+'_lookback'+str(lookback)+'_loss'+loss+'.csv')

if __name__ == '__main__':
    history_size = {
    'M3Year': 20,
    'M3Quart': 20,
    'M3Month': 20,
    'M3Other': 10
    }

    periods = {
    'M3Year': 0,
    'M3Quart': 4,
    'M3Month': 12,
    'M3Other': 0
    }

    iterations = {
    'M3Year': 200,
    'M3Quart': 300,
    'M3Month': 1000,
    'M3Other': 300
    }

    for i in range(5):
        for repeat in range(1,11):
            for lookback in range(2,4):
                for loss in ['SMAPE','MAPE','MASE']:
                    M3Experiment.train(repeat = repeat,
                                    lookback = lookback, 
                                    loss = loss,
                                    history_size = history_size , 
                                    iterations = iterations)

        results = str(evaluate())
        with open("result.txt","a") as f:
            f.write(results+"\n")