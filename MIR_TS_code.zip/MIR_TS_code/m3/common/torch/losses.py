# This source code is provided for the purposes of scientific reproducibility
# under the following limited license from Element AI Inc. The code is an
# implementation of the N-BEATS model (Oreshkin et al., N-BEATS: Neural basis
import torch as t

from common.torch.ops import divide_no_nan

def mape_loss(forecast: t.Tensor, target: t.Tensor, mask: t.Tensor) -> t.float:
    
    weights = divide_no_nan(mask, target)
    return t.mean(t.abs((forecast - target) * weights))

def smape_1_loss(forecast: t.Tensor, target: t.Tensor, mask: t.Tensor) -> t.float:
    
    return 200 * t.mean(divide_no_nan(t.abs(forecast - target), forecast.data + target.data) * mask)


def smape_2_loss(forecast, target, mask) -> t.float:
    
    return 200 * t.mean(divide_no_nan(t.abs(forecast - target),
                                      t.abs(forecast.data) + t.abs(target.data)) * mask)


def mase_loss(insample: t.Tensor, freq: int,
              forecast: t.Tensor, target: t.Tensor, mask: t.Tensor) -> t.float:
    
    masep = t.mean(t.abs(insample[:, freq:] - insample[:, :-freq]), dim=1)
    masked_masep_inv = divide_no_nan(mask, masep[:, None])
    return t.mean(t.abs(target - forecast) * masked_masep_inv)

def PSNR_loss(forecast, target, mask):
    
    forecast = forecast*mask
    maxV2 = t.square(t.max(forecast, dim=1))
    MSE = t.nn.MSELoss(reduction='none')
    PSNR = 10*t.log10(maxV2/t.mean(MSE(forecast, target),dim=1))

    return t.mean(PSNR)