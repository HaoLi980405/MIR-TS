Using 'python main.py' to obtain the results.

Results store in the 'result.txt'