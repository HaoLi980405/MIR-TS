import pandas as pd
from summary.m3 import evaluate

generic = pd.DataFrame(evaluate(), index = ['SMAPE'])

print(generic)
