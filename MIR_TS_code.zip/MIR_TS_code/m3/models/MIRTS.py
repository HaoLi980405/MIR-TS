
from typing import Tuple

import numpy as np
import torch as t
import torch.nn.functional as F
from common.torch.losses import smape_2_loss
from copy import deepcopy

class Block(t.nn.Module):
   
    def __init__(self,
                 input_size: int,
                 theta_size: int,
                 basis_function: t.nn.Module,
                 layers: int,
                 layer_size: int,
                 ):
       
        super().__init__()
        self.layers = t.nn.ModuleList([t.nn.Linear(in_features=input_size, out_features=layer_size)] +
                                      [t.nn.Linear(in_features=layer_size, out_features=layer_size)
                                       for _ in range(layers-1)])
        self.basis_parameters = t.nn.Linear(in_features=layer_size, out_features=theta_size)
        self.basis_function = basis_function

    def forward(self, x: t.Tensor) -> Tuple[t.Tensor, t.Tensor]:
        block_input = x
        for layer in self.layers:
            block_input = layer(block_input)
            block_input = F.relu(block_input)
        basis_parameters = self.basis_parameters(block_input)
        
        return self.basis_function(basis_parameters)
        
class MIRTS(t.nn.Module):
    
    def __init__(self, backcast_blocks: t.nn.ModuleList, prediction_blocks: t.nn.ModuleList):
        super().__init__()
        self.backcast_blocks = backcast_blocks
        self.prediction_blocks = prediction_blocks

    def forward(self, x: t.Tensor, input_mask: t.Tensor) -> t.Tensor:
        
        residuals = x.flip(dims=(1,))
        input_mask = input_mask.flip(dims=(1,))
        forecasting = x[:, -1:]
        
        for i in range(len(self.backcast_blocks)):
            backcast = self.backcast_blocks[i](residuals)
            residuals = (residuals - backcast) * input_mask
            prediction = self.prediction_blocks[i](residuals)
            forecasting = forecasting + prediction
        
        return forecasting


class GenericBasis(t.nn.Module):
    """
    Generic basis function.
    """
    def __init__(self):
        super().__init__()

    def forward(self, theta: t.Tensor):
        return theta

